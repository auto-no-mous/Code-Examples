﻿/*
Имеется файл «books.csv», хранящий в себе данные на книги в библиотеке. Строка файла может иметь вид:
Data Scientists at Work,Sebastian Gutierrez,data_science,230,Apress
где:
Data Scientists at Work – это название книги
Sebastian Gutierrez – автор книги
data_science – жанр
230 – высота книги в миллиметрах (я не знаю, зачем эти данные присутствуют, но они есть)
Apress – издатель

В качестве разделителя используется символ «,», но запятая также может быть и внутри названия книги или автора. Например:
Fundamentals of Wavelets,"Goswami, Jaideva",signal_processing,228,Wiley

где Goswami, Jaideva – это автор книги
Кроме того, у книги может не быть автора или издательства. Это выглядит вот так:
"World's Greatest Trials, The",,history,210,
то есть, даже если автор или издательство не указано, разделитель всё равно будет в этой позиции

ЗАДАЧА: реализуйте структуру, представляющую информацию о книгах. У структуры должен быть конструктор, принимающий в качестве аргумента одну строку вида
«Fundamentals of Wavelets,"Goswami, Jaideva",signal_processing,228,Wiley»

и заполняющий поля структуры корректно, учитывая все вариации входных строк. Если поля «автор» или «издательство» пустые, в соответствующих полях структуры указать строку «<no data>».
Также у структуры должен быть метод «ShowInfo()», выводящий информацию о книге.

Напишите программу, считывающую файл «books.csv», заполняющую список из структур, представляющих книгу. Выведите информацию обо всех добавленных книгах.

*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace BookLibrary
{
    struct Book
    {
        public string title;
        public string author;
        public string genre;
        public int height;
        public string publisher;

        public void ShowInfo()
        {
            void DrawLine(string item, string name)
            {
                Console.Write(item+": ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\"{0}\"", name);
                Console.ForegroundColor = ConsoleColor.Gray;
            }
            DrawLine("Book", title);
            DrawLine("Author", author);
            DrawLine("Genre", genre);
            DrawLine("Book", title);
            DrawLine("Height", height.ToString());
            DrawLine("Publisher", publisher);
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("-----------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public Book(string line)
        {
            string t;
            string a;
            string g;
            int h;
            string p;
            if (line.Contains('\"'))
            {
                if (line[0] == '\"')
                {
                    int pos = line.IndexOf('\"', 1);
                    title = line.Substring(1, pos - 1);
                    line = line.Substring(pos + 2);
                }
                else
                {
                    int pos = line.IndexOf(',');
                    title = line.Substring(0, pos - 1);
                    line = line.Substring(pos+1);
                }

                if (line[0] == '\"')
                {
                    int pos = line.IndexOf('\"', 1);
                    author = line.Substring(1, pos - 1);
                    line = line.Substring(pos + 2);
                }
                else
                {
                    int pos = line.IndexOf(',');
                    author = line.Substring(0, pos + 1);
                    line = line.Substring(pos+1);
                }

                string[] other = line.Split(',');
                genre = other[0];
                height = int.Parse(other[1]);
                publisher = other[2];
            }

            else
            {
                string[] other = line.Split(',');
                title = other[0];
                author = other[1];
                genre = other[2];
                height = int.Parse(other[3]);
                publisher = other[4];
            }
            if (author == "")
                author = "<no data>";
            if (publisher == "")
                publisher = "<no data>";
        }        
    }
    class Library
    {
        static int count = 0;
        private List <Book> Db;

        public Library ()
        {
            Db = new List<Book>();
        }

        public void ShowAllBooks()
        {
            foreach (Book b in Db)
            {
                b.ShowInfo();
            }
        }
        public void LoadFromFile(string path)
        {
            try
            {
                using (var sr = new StreamReader(path, Encoding.UTF8))
                {
                    string st = sr.ReadLine();
                    while (st != null)
                    {
                        Add(st);
                        st = sr.ReadLine();
                    }
                    sr.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void Add (string line)
        {
                Book b = new Book(line);
                Db.Add(b);
                count++;
        }
        public int Count 
        { 
            get
            {
                return count;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Library myLibrary = new Library();
            myLibrary.LoadFromFile("books.csv");
            Console.WriteLine("Total books added: {0}", myLibrary.Count);
            myLibrary.ShowAllBooks();
        }
    }
}